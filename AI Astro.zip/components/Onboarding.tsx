
import React, { useState } from 'react';
import { UserProfile } from '../types';
import { getVedicIdentity } from '../services/geminiService';
import { Star, Loader2 } from 'lucide-react';

interface OnboardingProps {
  onComplete: (profile: UserProfile) => void;
}

const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [profile, setProfile] = useState<Partial<UserProfile>>({
    name: '',
    birthDate: '',
    birthTime: '',
    birthLocation: '',
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      // AI used for 100% accurate Vedic Rashi/Lagna identification
      const { rashi, lagna } = await getVedicIdentity(profile);
      onComplete({ 
        name: profile.name!,
        birthDate: profile.birthDate!,
        birthTime: profile.birthTime!,
        birthLocation: profile.birthLocation!,
        rashi, 
        lagna 
      });
    } catch (error) {
      console.error("Vedic calculation failed", error);
      alert("ग्रहों की गणना में त्रुटि हुई। कृपया विवरण पुनः जाँचें।");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10 p-8 glass-panel rounded-3xl saffron-glow animate-in fade-in zoom-in duration-500">
      <div className="text-center mb-8">
        <div className="bg-orange-500/10 p-4 rounded-full w-20 h-20 mx-auto flex items-center justify-center mb-4">
            <Star className={`text-orange-500 w-10 h-10 ${loading ? 'animate-spin' : 'animate-pulse'}`} />
        </div>
        <h2 className="cinzel text-3xl font-bold text-orange-500">वैदिक गणना</h2>
        <p className="text-stone-400 mt-2 font-medium">सटीक कुंडली के लिए अपना विवरण दर्ज करें।</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-bold text-stone-300 mb-2">आपका नाम</label>
          <input
            required
            disabled={loading}
            type="text"
            className="w-full bg-stone-900/50 border border-stone-700 rounded-xl px-4 py-3 focus:ring-2 focus:ring-orange-500 outline-none text-white transition-all disabled:opacity-50"
            value={profile.name}
            onChange={(e) => setProfile({ ...profile, name: e.target.value })}
            placeholder="जैसे: राहुल शर्मा"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-bold text-stone-300 mb-2">जन्म तिथि</label>
            <input
              required
              disabled={loading}
              type="date"
              className="w-full bg-stone-900/50 border border-stone-700 rounded-xl px-4 py-3 focus:ring-2 focus:ring-orange-500 outline-none text-white transition-all disabled:opacity-50"
              value={profile.birthDate}
              onChange={(e) => setProfile({ ...profile, birthDate: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-stone-300 mb-2">जन्म समय</label>
            <input
              required
              disabled={loading}
              type="time"
              className="w-full bg-stone-900/50 border border-stone-700 rounded-xl px-4 py-3 focus:ring-2 focus:ring-orange-500 outline-none text-white transition-all disabled:opacity-50"
              value={profile.birthTime}
              onChange={(e) => setProfile({ ...profile, birthTime: e.target.value })}
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-bold text-stone-300 mb-2">जन्म स्थान</label>
          <input
            required
            disabled={loading}
            type="text"
            className="w-full bg-stone-900/50 border border-stone-700 rounded-xl px-4 py-3 focus:ring-2 focus:ring-orange-500 outline-none text-white transition-all disabled:opacity-50"
            value={profile.birthLocation}
            onChange={(e) => setProfile({ ...profile, birthLocation: e.target.value })}
            placeholder="शहर, राज्य"
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full py-4 font-bold text-lg text-white bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-500 hover:to-amber-400 rounded-2xl transition-all shadow-lg hover:shadow-orange-500/25 active:scale-95 disabled:opacity-70 flex justify-center items-center gap-2"
        >
          {loading ? (
            <><Loader2 className="animate-spin" /> नक्षत्रों की गणना...</>
          ) : "ब्रह्मांडीय संरेखण देखें"}
        </button>
      </form>
    </div>
  );
};

export default Onboarding;