
import React, { useEffect, useState } from 'react';
import { UserProfile, NatalChart } from '../types';
import { getNatalReading } from '../services/geminiService';
import { Loader2, Zap, Star, Sparkles } from 'lucide-react';

interface NatalChartViewProps {
  profile: UserProfile;
}

const NatalChartView: React.FC<NatalChartViewProps> = ({ profile }) => {
  const [chart, setChart] = useState<NatalChart | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchChart = async () => {
      setLoading(true);
      try {
        const data = await getNatalReading(profile);
        setChart(data);
      } catch (error) {
        console.error("जन्म कुंडली प्राप्त करने में विफल", error);
      } finally {
        setLoading(false);
      }
    };
    fetchChart();
  }, [profile]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-24">
        <Loader2 className="w-16 h-16 text-orange-500 animate-spin mb-6" />
        <p className="cinzel text-2xl text-orange-500 font-bold">आकाश मंडल का विश्लेषण हो रहा है...</p>
      </div>
    );
  }

  if (!chart) return null;

  const placements = [
    { label: 'सूर्य (Sun)', value: chart.sun, desc: 'आत्मा और शक्ति' },
    { label: 'चंद्र (Moon)', value: chart.moon, desc: 'मन और भावनाएं' },
    { label: 'लग्न (Rising)', value: chart.rising, desc: 'व्यक्तित्व और स्वभाव' },
    { label: 'बुध (Mercury)', value: chart.mercury, desc: 'बुद्धि और संचार' },
    { label: 'शुक्र (Venus)', value: chart.venus, desc: 'प्रेम और सुख' },
    { label: 'मंगल (Mars)', value: chart.mars, desc: 'साहस और ऊर्जा' },
    { label: 'गुरु (Jupiter)', value: chart.jupiter, desc: 'ज्ञान और भाग्य' },
    { label: 'शनि (Saturn)', value: chart.saturn, desc: 'कर्म और अनुशासन' },
  ];

  return (
    <div className="grid lg:grid-cols-3 gap-10 animate-in fade-in duration-1000">
      <div className="lg:col-span-2 space-y-8">
        {/* Summary Panel */}
        <div className="glass-panel p-10 rounded-3xl border-orange-500/10">
          <div className="flex items-center gap-4 mb-8">
            <div className="bg-orange-500 p-2 rounded-lg">
                <Zap className="text-white" size={24} />
            </div>
            <h2 className="cinzel text-3xl font-bold text-orange-500">विस्तृत कुंडली विश्लेषण</h2>
          </div>
          <div className="prose prose-invert max-w-none">
            <p className="text-stone-200 leading-relaxed whitespace-pre-line text-lg font-medium">
              {chart.summary}
            </p>
          </div>
        </div>

        {/* Combinations / Yogas Section */}
        <div className="space-y-6">
          <div className="flex items-center gap-3 px-2">
            <Sparkles className="text-orange-500 w-7 h-7" />
            <h3 className="cinzel text-2xl text-stone-100 font-bold tracking-wider">ग्रहों की युति (Yogas)</h3>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            {chart.combinations && chart.combinations.length > 0 ? (
              chart.combinations.map((comb, idx) => (
                <div key={idx} className="glass-panel p-6 rounded-2xl border-stone-800 hover:border-orange-500/20 transition-all group saffron-glow">
                  <h4 className="text-orange-500 font-bold mb-3 text-lg flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-orange-500 rounded-full"></div>
                    {comb.planets}
                  </h4>
                  <p className="text-stone-300 text-sm leading-relaxed font-medium">
                    {comb.description}
                  </p>
                </div>
              ))
            ) : (
              <p className="text-stone-500 italic px-2">कोई विशेष युति नहीं पाई गई।</p>
            )}
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="flex items-center gap-2 px-2">
            <Star className="text-amber-500 fill-amber-500 w-5 h-5" />
            <h3 className="cinzel text-xl text-stone-100 font-bold tracking-wider">ग्रहों की स्थिति</h3>
        </div>
        <div className="grid gap-4">
          {placements.map((p) => (
            <div key={p.label} className="glass-panel p-5 rounded-2xl flex justify-between items-center group hover:bg-orange-500/10 transition-all border-stone-800">
              <div>
                <p className="text-[10px] text-stone-500 uppercase font-bold tracking-widest mb-1">{p.desc}</p>
                <p className="font-bold text-stone-100 text-lg">{p.label}</p>
              </div>
              <div className="text-right">
                <span className="cinzel text-orange-500 font-extrabold text-2xl">{p.value}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default NatalChartView;