
import React from 'react';
import { Sparkles, Moon, Sun, Compass, MessageSquare } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'horoscope', label: 'दैनिक राशिफल', icon: Sun },
    { id: 'chart', label: 'जन्म कुंडली', icon: Compass },
    { id: 'compatibility', label: 'गुण मिलान', icon: Sparkles },
    { id: 'oracle', label: 'ज्योतिष सलाह', icon: MessageSquare },
  ];

  return (
    <div className="min-h-screen flex flex-col max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
      <header className="py-8 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="bg-orange-600 p-2 rounded-full saffron-glow">
            <Moon className="text-white fill-white w-6 h-6" />
          </div>
          <h1 className="cinzel text-2xl font-bold tracking-widest text-orange-500">
            भाग्य दर्पण
          </h1>
        </div>
        <div className="hidden md:flex gap-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`text-sm font-bold transition-all hover:text-orange-400 ${
                activeTab === tab.id ? 'text-orange-500 border-b-2 border-orange-500 pb-1' : 'text-stone-400'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </header>

      <main className="flex-1 pb-24 md:pb-12">
        {children}
      </main>

      {/* Mobile Navigation */}
      <nav className="md:hidden fixed bottom-6 left-1/2 -translate-x-1/2 glass-panel saffron-glow rounded-3xl px-6 py-4 flex gap-8 items-center z-50">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`p-2 rounded-full transition-colors ${
                activeTab === tab.id ? 'bg-orange-500/20 text-orange-500' : 'text-stone-400'
              }`}
            >
              <Icon size={24} />
            </button>
          );
        })}
      </nav>
    </div>
  );
};

export default Layout;
