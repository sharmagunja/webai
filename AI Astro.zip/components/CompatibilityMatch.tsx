
import React, { useState } from 'react';
import { Sign } from '../types';
import { getCompatibility } from '../services/geminiService';
import { Heart, Loader2, Sparkles } from 'lucide-react';

interface CompatibilityMatchProps {
  userSign: Sign;
}

const CompatibilityMatch: React.FC<CompatibilityMatchProps> = ({ userSign }) => {
  const [partnerSign, setPartnerSign] = useState<Sign | ''>('');
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleMatch = async () => {
    if (!partnerSign) return;
    setLoading(true);
    try {
      const res = await getCompatibility(userSign, partnerSign as Sign);
      setAnalysis(res);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const signs = Object.values(Sign);

  return (
    <div className="max-w-4xl mx-auto space-y-10 animate-in fade-in zoom-in duration-700">
      <div className="text-center">
        <h2 className="cinzel text-4xl font-bold text-orange-500 mb-3">गुण मिलान एवं अनुकूलता</h2>
        <p className="text-stone-400 font-medium">दो राशियों के बीच के कर्मिक और प्रेम संबंधों का विश्लेषण करें।</p>
      </div>

      <div className="flex flex-col md:flex-row items-center justify-center gap-12 py-10">
        <div className="text-center group">
          <div className="w-28 h-28 bg-orange-500/10 rounded-3xl flex items-center justify-center border-2 border-orange-500/30 mb-4 mx-auto group-hover:scale-110 transition-transform shadow-xl">
            <span className="cinzel text-3xl font-bold text-orange-500">{userSign}</span>
          </div>
          <p className="text-xs text-stone-500 font-bold uppercase tracking-widest">आपकी राशि</p>
        </div>

        <div className="relative">
            <Heart className="w-16 h-16 text-rose-600 fill-rose-600/20 animate-pulse hidden md:block" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 hidden md:block">
                <Sparkles className="text-amber-400 w-6 h-6 animate-spin" />
            </div>
        </div>

        <div className="text-center">
          <select
            className="w-40 bg-stone-900 border-2 border-stone-800 rounded-3xl px-4 py-3 text-orange-500 font-bold focus:ring-2 focus:ring-orange-500 outline-none h-28 text-center cinzel appearance-none text-xl hover:border-orange-500/50 transition-all cursor-pointer shadow-xl"
            value={partnerSign}
            onChange={(e) => setPartnerSign(e.target.value as Sign)}
          >
            <option value="">चुनें</option>
            {signs.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
          <p className="text-xs text-stone-500 font-bold uppercase tracking-widest mt-4">साथी की राशि</p>
        </div>
      </div>

      <div className="text-center">
        <button
          onClick={handleMatch}
          disabled={!partnerSign || loading}
          className="px-12 py-4 bg-gradient-to-r from-orange-600 to-rose-600 text-white cinzel font-bold text-lg rounded-2xl hover:scale-105 transition-all disabled:opacity-50 shadow-xl shadow-orange-600/20 active:scale-95 flex items-center gap-3 mx-auto"
        >
          {loading ? <Loader2 className="animate-spin" /> : <><Sparkles size={20} /> सितारों का मिलान करें</>}
        </button>
      </div>

      {analysis && (
        <div className="glass-panel p-10 rounded-3xl border-orange-500/20 relative overflow-hidden animate-in fade-in slide-in-from-top-6">
          <div className="absolute -top-10 -right-10 opacity-5">
            <Heart size={200} className="text-rose-500" />
          </div>
          <h3 className="cinzel text-2xl text-orange-500 mb-6 flex items-center gap-3 font-bold">
            <Sparkles size={24} className="text-amber-500" />
            ज्योतिषीय निष्कर्ष
          </h3>
          <p className="text-stone-100 leading-relaxed text-lg whitespace-pre-line italic font-medium bg-stone-900/40 p-6 rounded-2xl border border-stone-800">
            {analysis}
          </p>
        </div>
      )}
    </div>
  );
};

export default CompatibilityMatch;
