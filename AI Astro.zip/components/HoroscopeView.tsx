
import React, { useEffect, useState } from 'react';
import { Sign, Horoscope } from '../types';
import { getDailyHoroscope } from '../services/geminiService';
import { Heart, Briefcase, HeartPulse, Loader2, Sparkles } from 'lucide-react';

interface HoroscopeViewProps {
  sign: Sign;
}

const HoroscopeView: React.FC<HoroscopeViewProps> = ({ sign }) => {
  const [horoscope, setHoroscope] = useState<Horoscope | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchHoroscope = async () => {
      setLoading(true);
      try {
        const data = await getDailyHoroscope(sign);
        setHoroscope(data);
      } catch (error) {
        console.error("राशिफल प्राप्त करने में विफल", error);
      } finally {
        setLoading(false);
      }
    };
    fetchHoroscope();
  }, [sign]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-24">
        <Loader2 className="w-16 h-16 text-orange-500 animate-spin mb-6" />
        <p className="cinzel text-2xl text-orange-500 font-bold animate-pulse">ग्रहों की गणना हो रही है...</p>
      </div>
    );
  }

  if (!horoscope) return null;

  const sections = [
    { icon: Heart, label: 'प्रेम और संबंध', content: horoscope.love, color: 'text-rose-500', bg: 'bg-rose-500/5' },
    { icon: Briefcase, label: 'करियर और धन', content: horoscope.career, color: 'text-amber-500', bg: 'bg-amber-500/5' },
    { icon: HeartPulse, label: 'स्वास्थ्य और ऊर्जा', content: horoscope.wellness, color: 'text-emerald-500', bg: 'bg-emerald-500/5' },
  ];

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-8 duration-1000">
      <div className="text-center">
        <div className="inline-block bg-orange-500/10 px-6 py-2 rounded-full mb-4 border border-orange-500/20">
            <span className="text-orange-500 font-bold tracking-widest uppercase text-sm">आज का राशिफल</span>
        </div>
        <h2 className="cinzel text-5xl font-extrabold text-orange-500 mb-3">{sign}</h2>
        <div className="h-1 w-24 bg-gradient-to-r from-transparent via-orange-500 to-transparent mx-auto"></div>
      </div>

      <div className="glass-panel p-10 rounded-3xl border-orange-500/20 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-orange-500 via-amber-400 to-orange-500"></div>
        
        <p className="text-xl md:text-2xl leading-relaxed text-stone-100 text-center mb-12 font-medium italic">
          "{horoscope.prediction}"
        </p>

        <div className="grid md:grid-cols-3 gap-8">
          {sections.map((sec) => (
            <div key={sec.label} className={`${sec.bg} p-8 rounded-2xl border border-stone-800 hover:border-orange-500/30 transition-all group`}>
              <div className="flex items-center gap-3 mb-4">
                <sec.icon className={`${sec.color} group-hover:scale-110 transition-transform`} size={24} />
                <h3 className="font-bold text-lg text-stone-200">{sec.label}</h3>
              </div>
              <p className="text-stone-400 leading-relaxed font-medium">{sec.content}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-wrap justify-center gap-6">
          <div className="px-8 py-3 bg-stone-900 rounded-2xl border border-orange-500/20 text-orange-400 font-bold shadow-lg">
            शुभ अंक: <span className="text-white text-xl ml-2">{horoscope.luckyNumber}</span>
          </div>
          <div className="px-8 py-3 bg-stone-900 rounded-2xl border border-orange-500/20 text-orange-400 font-bold shadow-lg">
            शुभ रंग: <span className="text-white text-xl ml-2 uppercase">{horoscope.luckyColor}</span>
          </div>
          <div className="px-8 py-3 bg-orange-600 rounded-2xl text-white font-bold shadow-lg shadow-orange-600/20">
            ऊर्जा स्तर: <span className="text-xl ml-2">{horoscope.intensity}/10</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HoroscopeView;
