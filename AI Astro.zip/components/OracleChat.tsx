
import React, { useState, useRef, useEffect } from 'react';
import { UserProfile, ChatMessage } from '../types';
import { askOracle } from '../services/geminiService';
import { Send, Loader2, Sparkles } from 'lucide-react';

interface OracleChatProps {
  profile: UserProfile;
}

const OracleChat: React.FC<OracleChatProps> = ({ profile }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages((prev) => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      // Fixed: sunSign replaced with rashi and lagna which exist on UserProfile
      const context = `उपयोगकर्ता ${profile.name} है, जन्म तिथि ${profile.birthDate} (राशि: ${profile.rashi}, लग्न: ${profile.lagna})। वे ज्योतिषीय सलाह मांग रहे हैं।`;
      const response = await askOracle(userMsg, context);
      setMessages((prev) => [...prev, { role: 'model', text: response }]);
    } catch (error) {
      setMessages((prev) => [...prev, { role: 'model', text: "ब्रह्मांडीय संकेतों में बाधा है। कृपया पुनः प्रयास करें।" }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto h-[75vh] flex flex-col glass-panel rounded-3xl overflow-hidden border-orange-500/20 shadow-2xl">
      <div className="p-5 bg-stone-900 border-b border-orange-500/20 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-orange-500 rounded-full p-2">
            <Sparkles className="text-white w-5 h-5" />
          </div>
          <span className="cinzel font-bold text-orange-500 text-lg">ज्योतिष प्रश्नोत्तरी</span>
        </div>
        <span className="text-xs text-stone-500 font-bold bg-stone-800 px-3 py-1 rounded-full">वैदिक मार्गदर्शन</span>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 space-y-8 scroll-smooth bg-stone-950/30">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center opacity-60">
            <div className="bg-orange-500/10 p-8 rounded-full mb-6">
                <Sparkles size={64} className="text-orange-500 animate-pulse" />
            </div>
            <p className="cinzel text-2xl font-bold text-stone-100 mb-2">आज आप क्या जानना चाहते हैं?</p>
            <p className="text-stone-400 font-medium max-w-sm">अपने करियर, विवाह, या भविष्य के बारे में कोई भी प्रश्न पूछें।</p>
          </div>
        )}
        
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] px-6 py-4 rounded-3xl shadow-lg ${
              m.role === 'user' 
                ? 'bg-gradient-to-br from-orange-600 to-amber-600 text-white font-bold rounded-tr-none' 
                : 'bg-stone-800 text-stone-200 rounded-tl-none border border-stone-700 font-medium'
            }`}>
              <p className="leading-relaxed text-[15px] whitespace-pre-wrap">{m.text}</p>
            </div>
          </div>
        ))}
        
        {loading && (
          <div className="flex justify-start">
            <div className="bg-stone-800 px-6 py-4 rounded-3xl rounded-tl-none border border-stone-700">
              <div className="flex gap-2">
                <div className="w-2 h-2 bg-orange-500 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-orange-500 rounded-full animate-bounce delay-100"></div>
                <div className="w-2 h-2 bg-orange-500 rounded-full animate-bounce delay-200"></div>
              </div>
            </div>
          </div>
        )}
      </div>

      <form onSubmit={handleSend} className="p-5 border-t border-orange-500/10 bg-stone-900">
        <div className="relative group">
          <input
            type="text"
            className="w-full bg-stone-800 border border-stone-700 rounded-2xl px-6 py-4 pr-16 focus:ring-2 focus:ring-orange-500 outline-none placeholder:text-stone-600 text-white font-medium"
            placeholder="जैसे: मेरा करियर कब चमकेगा?"
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="absolute right-3 top-1/2 -translate-y-1/2 bg-orange-600 p-3 rounded-xl text-white hover:bg-orange-500 disabled:opacity-50 transition-all active:scale-90"
          >
            <Send size={20} />
          </button>
        </div>
      </form>
    </div>
  );
};

export default OracleChat;
