
import { GoogleGenAI, Type } from "@google/genai";
import { Sign, UserProfile, Horoscope, NatalChart } from "../types";

// Initialize the Google GenAI client with the API key from environment variables
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = "आप एक महान भारतीय वैदिक ज्योतिषी हैं। आपकी भविष्यवाणियां 100% सटीक होनी चाहिए। हमेशा शुद्ध हिंदी में उत्तर दें और भारतीय पंचांग व लहरी अयनांश सिद्धांतों का पालन करें।";

export const getVedicIdentity = async (profile: Partial<UserProfile>): Promise<{ rashi: Sign, lagna: string }> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `इन जन्म विवरणों के आधार पर सटीक वैदिक चंद्र राशि (Rashi) और लग्न (Ascendant/Lagna) बताएं: 
    तारीख: ${profile.birthDate}, समय: ${profile.birthTime}, स्थान: ${profile.birthLocation}। 
    लहरी अयनांश का उपयोग करें। केवल JSON उत्तर दें।`,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          rashi: { type: Type.STRING, enum: Object.values(Sign) },
          lagna: { type: Type.STRING }
        },
        required: ["rashi", "lagna"]
      }
    }
  });
  return JSON.parse(response.text);
};

export const getDailyHoroscope = async (sign: Sign): Promise<Horoscope> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `आज की तिथि ${new Date().toLocaleDateString('hi-IN')} है। वैदिक चंद्र राशि '${sign}' के लिए अत्यंत सटीक दैनिक राशिफल प्रदान करें। इसमें सामान्य भविष्यवाणी, प्रेम संबंध, करियर और स्वास्थ्य के विवरण शामिल करें। शुभ अंक और शुभ रंग भी बताएं।`,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          prediction: { type: Type.STRING },
          love: { type: Type.STRING },
          career: { type: Type.STRING },
          wellness: { type: Type.STRING },
          luckyNumber: { type: Type.STRING },
          luckyColor: { type: Type.STRING },
          intensity: { type: Type.NUMBER }
        },
        required: ["prediction", "love", "career", "wellness", "luckyNumber", "luckyColor", "intensity"]
      }
    }
  });

  return JSON.parse(response.text);
};

export const getNatalReading = async (profile: UserProfile): Promise<NatalChart> => {
  const prompt = `${profile.name} के लिए एक विस्तृत वैदिक जन्म कुंडली विश्लेषण तैयार करें। जन्म विवरण: ${profile.birthDate}, ${profile.birthTime}, ${profile.birthLocation}। 
  ग्रहों की स्थिति (जैसे सूर्य मेष में, शनि कुंभ में आदि) और महत्वपूर्ण योगों का विश्लेषण करें।`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          sun: { type: Type.STRING },
          moon: { type: Type.STRING },
          rising: { type: Type.STRING },
          mercury: { type: Type.STRING },
          venus: { type: Type.STRING },
          mars: { type: Type.STRING },
          jupiter: { type: Type.STRING },
          saturn: { type: Type.STRING },
          summary: { type: Type.STRING },
          combinations: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                planets: { type: Type.STRING },
                description: { type: Type.STRING }
              },
              required: ["planets", "description"]
            }
          }
        },
        required: ["sun", "moon", "rising", "mercury", "venus", "mars", "jupiter", "saturn", "summary", "combinations"]
      }
    }
  });

  return JSON.parse(response.text);
};

export const getCompatibility = async (userSign: Sign, partnerSign: Sign): Promise<string> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `वैदिक राशि ${userSign} और ${partnerSign} के बीच अष्टकूट मिलान के सिद्धांतों के आधार पर प्रेम अनुकूलता का विश्लेषण करें।`,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION
    }
  });
  return response.text;
};

export const askOracle = async (question: string, context: string): Promise<string> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `संदर्भ: ${context}. प्रश्न: ${question}.`,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION
    }
  });
  return response.text;
};
